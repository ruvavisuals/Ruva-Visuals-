
import React from 'react';

const thumbnails = [
  "/thumbnails/thumb1.jpg",
  "/thumbnails/thumb2.jpg",
  "/thumbnails/thumb3.jpg"
];

export default function Portfolio() {
  return (
    <main className="min-h-screen bg-black text-white p-6">
      <header className="mb-12 text-center">
        <h1 className="text-4xl font-bold">Ruva Visuals</h1>
        <p className="text-xl mt-2">Crafting high-converting thumbnails for top YouTubers.</p>
      </header>

      <section className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6 max-w-6xl mx-auto">
        {thumbnails.map((src, index) => (
          <img
            key={index}
            src={src}
            alt={`Thumbnail ${index + 1}`}
            className="rounded-2xl shadow-lg hover:scale-105 transition-transform"
          />
        ))}
      </section>

      <footer className="mt-20 text-center text-sm text-gray-400">
        <p>Contact: sarveshmore136@gmail.com | 9082041520</p>
        <p>Instagram: <a href="https://instagram.com/ruvavisuals" className="text-blue-400 hover:underline">@ruvavisuals</a></p>
        <p className="mt-2">© {new Date().getFullYear()} Ruva Visuals. All rights reserved.</p>
      </footer>
    </main>
  );
}
